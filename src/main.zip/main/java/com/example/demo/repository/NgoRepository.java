package com.example.demo.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.entity.*;
	
	public interface NgoRepository extends JpaRepository<Ngo, Integer> {

	    boolean existsByRegNo(int regNo);

	}


