package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dto.*;
import com.example.demo.entity.*;
import com.example.demo.repository.*;
@Service
public class NgoService {
	



	    @Autowired
	    private NgoRepository ngoRepository;

	    public Ngo registerNgo(NgoDTO ngoDTO) {

	        if (ngoRepository.existsByRegNo(ngoDTO.getRegNo())) {
	            throw new RuntimeException("Registration Number Already Exists");
	        }

	        Ngo ngo = new Ngo();

	        ngo.setUid(ngoDTO.getUid());
	        ngo.setNgoName(ngoDTO.getNgoName());
	        ngo.setRegNo(ngoDTO.getRegNo());
	        ngo.setAddress(ngoDTO.getAddress());
	        ngo.setPhone(ngoDTO.getPhone());
	        ngo.setEmail(ngoDTO.getEmail());

	        return ngoRepository.save(ngo);
	    }
	}


