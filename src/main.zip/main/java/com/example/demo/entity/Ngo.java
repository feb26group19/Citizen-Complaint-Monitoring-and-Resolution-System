package com.example.demo.entity;
import jakarta.persistence.*;

@Entity
@Table(name = "ngo")
public class Ngo {
	

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    @Column(name = "ngo_id")
	    private int ngoId;

	    @Column(name = "uid")
	    private int uid;

	    @Column(name = "ngo_name")
	    private String ngoName;

	    @Column(name = "reg_no", unique = true)
	    private int regNo;

	    private String address;

	    private String phone;

	    private String email;

	    public Ngo() {
	    }

	    public int getNgoId() {
	        return ngoId;
	    }

	    public void setNgoId(int ngoId) {
	        this.ngoId = ngoId;
	    }

	    public int getUid() {
	        return uid;
	    }

	    public void setUid(int uid) {
	        this.uid = uid;
	    }

	    public String getNgoName() {
	        return ngoName;
	    }

	    public void setNgoName(String ngoName) {
	        this.ngoName = ngoName;
	    }

	    public int getRegNo() {
	        return regNo;
	    }

	    public void setRegNo(int regNo) {
	        this.regNo = regNo;
	    }

	    public String getAddress() {
	        return address;
	    }

	    public void setAddress(String address) {
	        this.address = address;
	    }

	    public String getPhone() {
	        return phone;
	    }

	    public void setPhone(String phone) {
	        this.phone = phone;
	    }

	    public String getEmail() {
	        return email;
	    }

	    public void setEmail(String email) {
	        this.email = email;
	    }
	}


