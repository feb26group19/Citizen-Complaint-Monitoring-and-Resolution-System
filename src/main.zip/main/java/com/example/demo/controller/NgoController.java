package com.example.demo.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.example.demo.dto.*;
import com.example.demo.entity.*;
import com.example.demo.service.*;

@RestController
@RequestMapping("/ngo")
@CrossOrigin(origins = "*")
public class NgoController {
	
	    @Autowired
	    private NgoService ngoService;

	    @PostMapping("/register")
	    public Ngo registerNgo(@RequestBody NgoDTO ngoDTO) {
	        return ngoService.registerNgo(ngoDTO);
	    }
	}
	


