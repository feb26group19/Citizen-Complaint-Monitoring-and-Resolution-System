package com.example.demo.dto;

public class NgoDTO {
	

	    private int uid;
	    private String ngoName;
	    private int regNo;
	    private String address;
	    private String phone;
	    private String email;

	    public NgoDTO() {
	    }

	    public NgoDTO( int uid, String ngoName, int regNo, String address, String phone, String email) {
	       this.uid = uid;
	        this.ngoName = ngoName;
	        this.regNo = regNo;
	        this.address = address;
	        this.phone = phone;
	        this.email = email;
	    }

	    public int getUid() {
	        return uid;
	    }

	    public void setUid(int uid) {
	        this.uid = uid;
	    }

	    public String getNgoName() {
	        return ngoName;
	    }

	    public void setNgoName(String ngoName) {
	        this.ngoName = ngoName;
	    }

	    public int getRegNo() {
	        return regNo;
	    }

	    public void setRegNo(int regNo) {
	        this.regNo = regNo;
	    }

	    public String getAddress() {
	        return address;
	    }

	    public void setAddress(String address) {
	        this.address = address;
	    }

	    public String getPhone() {
	        return phone;
	    }

	    public void setPhone(String phone) {
	        this.phone = phone;
	    }

	    public String getEmail() {
	        return email;
	    }

	    public void setEmail(String email) {
	        this.email = email;
	    }
	}


